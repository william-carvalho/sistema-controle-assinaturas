package com.acme.sistema_controle_assinaturas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SistemaControleAssinaturasApplication {

	public static void main(String[] args) {
		SpringApplication.run(SistemaControleAssinaturasApplication.class, args);
	}

}
