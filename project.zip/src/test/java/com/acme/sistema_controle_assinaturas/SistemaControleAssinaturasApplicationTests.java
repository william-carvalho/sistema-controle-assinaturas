package com.acme.sistema_controle_assinaturas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SistemaControleAssinaturasApplicationTests {

	@Test
	void contextLoads() {
	}

}
